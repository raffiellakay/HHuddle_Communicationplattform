package com.knoettner.hhuddle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HHuddleApplicationTests {

    @Test
    void contextLoads() {
    }

}
