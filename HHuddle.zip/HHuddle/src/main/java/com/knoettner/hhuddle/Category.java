package com.knoettner.hhuddle;

public enum Category {
    BLACKBOARD,
    FRONTPAGE,
    PACKAGE,
    EVENTS,
    EXCHANGE;

}
