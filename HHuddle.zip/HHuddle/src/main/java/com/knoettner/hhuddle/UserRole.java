package com.knoettner.hhuddle;

public enum UserRole {
    RESIDENT,
    PManagement;
}
