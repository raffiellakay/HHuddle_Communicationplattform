package com.knoettner.hhuddle.dto.mapper;

public class HouseMapper {
}
