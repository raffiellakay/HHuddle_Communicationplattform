package com.knoettner.hhuddle.repository;

import com.knoettner.hhuddle.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
