package com.knoettner.hhuddle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HHuddleApplication {

    public static void main(String[] args) {
        SpringApplication.run(HHuddleApplication.class, args);
    }

}
